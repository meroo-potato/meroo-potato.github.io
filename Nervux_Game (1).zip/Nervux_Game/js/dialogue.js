const NAME='Omar Hany';
export class Dialogue {
  constructor(game){this.game=game;this.lines=[];this.i=0;this.el=document.querySelector('#dialogue');this.text=document.querySelector('#dialogue-text');this.el.onclick=()=>this.next();}
  start(lines){this.lines=lines.map(x=>x.replaceAll('[playername]',NAME));this.i=0;this.game.cutscene=true;this.el.classList.remove('hidden');this.show();}
  show(){this.text.textContent=this.lines[this.i]||'';}
  next(){this.i++;if(this.i>=this.lines.length){this.el.classList.add('hidden');this.game.cutscene=false;}else this.show();}
}