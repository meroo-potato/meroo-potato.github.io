import {Projectile} from './projectiles.js';
export const PHASES=[
 {name:'Introduction',hp:3000,color:'#f43f5e'},
 {name:'UFOs',hp:6000,color:'#a855f7'},
 {name:'M5 Miniboss',hp:6000,color:'#22c55e'},
 {name:'Netrex Miniboss',hp:6000,color:'#06b6d4'},
 {name:'New Mechanics',hp:3000,color:'#facc15'},
 {name:'Defend Snake',hp:3000,color:'#eab308'},
 {name:"Xuvren's Revenge",hp:2000,color:'#ef4444'}
];
export class Boss {
 constructor(game){this.game=game;this.x=game.w/2;this.y=130;this.hp=40000;this.timer=0;this.attack=0;this.phaseHp=0;}
 reset(p){this.phaseHp=PHASES[p-1].hp;this.hp=this.phaseHp;this.timer=0;this.attack=0;this.x=this.game.w/2;}
 damage(n){if(this.phaseHp<=0)return;this.phaseHp=Math.max(0,this.phaseHp-n);this.game.ui();if(this.phaseHp===0)this.game.nextPhase();}
 update(dt){const g=this.game,p=g.phase;this.timer+=dt;this.attack+=dt;if(p===2)this.x=g.w/2+Math.sin(this.timer*.9)*Math.min(260,g.w*.3);else if(p===5)this.x=g.w/2+Math.sin(this.timer*2)*Math.min(300,g.w*.35);else if(p===3||p===4)this.x=g.w/2+Math.sin(this.timer*.7)*Math.min(320,g.w*.4); if(this.attack>=(p===1?1:p===2?1:p===3?1.4:1.1)){this.attack=0;this.fire(p);} }
 fire(p){const g=this, a=Math.atan2(g.player.y-this.y,g.player.x-this.x);const shoot=(ang,col,dmg=1,hom=false)=>g.projectiles.push(new Projectile(this.x,this.y,Math.cos(ang)*150,Math.sin(ang)*150,col,dmg,6,hom)); if(p===1||p===2){for(let i=0;i<8;i++)shoot((i/8)*Math.PI*2,this.attack%3<1?'#38bdf8':'#60a5fa');}else if(p===3){for(let i=0;i<8;i++)shoot(a+(i-3.5)*.22,'#60a5fa');}else if(p===4){shoot(a,'#a855f7',1);shoot(a+.5,'#22d3ee',1,true);shoot(a-.5,'#22d3ee',1,true);}else if(p===5){for(let i=0;i<10;i++)shoot(a+(i-4.5)*.1,'#fde047');}else if(p===6){shoot(a,'#22c55e',1,true);}else{const colors=['#ef4444','#38bdf8','#a855f7','#4ade80','#fde047'];for(let i=0;i<10;i++){const q=colors[Math.random()<.4?0:Math.floor(Math.random()*colors.length)];const b=new Projectile(this.x,this.y,Math.cos(i*.63)*170,Math.sin(i*.63)*170,q);b.red=q==='#ef4444';g.projectiles.push(b);}}}
 draw(c){const p=this.game.phase, ph=PHASES[p-1];c.save();c.translate(this.x,this.y);c.shadowBlur=30;c.shadowColor=ph.color;c.fillStyle=ph.color;c.strokeStyle='#fff';c.lineWidth=2;if(p===3)c.fillRect(-48,-28,96,56);else if(p===4){c.beginPath();c.moveTo(-45,30);c.lineTo(0,-35);c.lineTo(45,30);c.closePath();c.fill();}else{c.beginPath();c.arc(0,0,42,0,Math.PI*2);c.fill();}c.stroke();c.fillStyle='#000';c.font='26px serif';c.textAlign='center';c.fillText(p===3?'M5':p===4?'N':'👁',0,9);c.restore();}
}