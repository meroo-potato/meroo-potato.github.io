export const FORMS = {
  yellow:{name:'Yellow',color:'#fde047',damage:120,speed:1,desc:'Melee'},
  purple:{name:'Purple',color:'#d946ef',damage:30,speed:1,desc:'Projectiles'},
  green:{name:'Green',color:'#4ade80',damage:15,speed:1,desc:'Auto-target'},
  white:{name:'White',color:'#f8fafc',damage:25,speed:.62,desc:'Small melee'},
  red:{name:'Red',color:'#ef4444',damage:0,speed:1,desc:'Heal from red'},
};
export class Player {
  constructor(game){ this.game=game; this.x=innerWidth/2; this.y=innerHeight*.75; this.form='yellow'; this.hearts=5; this.invincible=0; this.redCaught=0; this.down=false; this.hold=0; }
  setForm(n){ if(this.game.phase===3 && !['green','purple','red'].includes(n)) return; if(this.game.phase===6)n='yellow'; if(this.game.phase===7)n='red'; this.form=n; this.game.ui(); }
  move(x,y){ const g=this.game; const invert=g.inverted?-1:1; this.x=Math.max(8,Math.min(g.w-8,(x-g.w/2)*invert+g.w/2)); this.y=Math.max(8,Math.min(g.h-8,(y-g.h/2)*invert+g.h/2)); }
  hit(amount=1){ if(this.invincible>0 || this.game.cutscene)return; this.hearts=Math.max(0,this.hearts-amount); this.invincible=3; this.game.flash('YOU WERE HIT'); if(!this.hearts)this.game.end(false); this.game.ui(); }
  update(dt){ if(this.invincible>0)this.invincible-=dt; if(this.down)this.y=Math.min(this.game.h-35,this.y+dt*18); if(this.game.mouseDown)this.hold+=dt; else this.hold=0; }
  draw(c){ const f=FORMS[this.form], r=this.form==='white'?7:11; c.save(); c.globalAlpha=this.invincible>0?(.45+.3*Math.sin(performance.now()/50)):1; c.shadowBlur=20;c.shadowColor=f.color;c.fillStyle=f.color;c.beginPath();c.arc(this.x,this.y,r,0,Math.PI*2);c.fill();c.strokeStyle='#fff';c.lineWidth=1;c.stroke(); if(this.form==='red'){c.fillStyle='#fff';c.font='9px monospace';c.textAlign='center';c.fillText(this.redCaught,this.x,this.y+3)} c.restore(); }
}