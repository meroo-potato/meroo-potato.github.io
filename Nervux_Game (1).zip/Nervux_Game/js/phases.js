export const PHASE_DIALOGUE={
  1:['So you found me, [playername].','Let us see if your cursor can survive the void.'],
  2:['Damn it HOW did you get these POWERS?!?!','You will NOT survive long though','I still have alot of things that you don’t.','one of them is FRIENDS.','UFO’S ASSIST ME'],
  3:['Nervux leaves. A quieter shape takes his place.','I built this website from pain, love, and impossible hours.','You will not find HIM. I will stop you first.'],
  4:['Netrex appears, without the badge.','I know how many times you have died.','This fight is personal.'],
  5:['Nervux returns, furious.','Think Omar Hany think.'],
  6:['A giant UFO blots out the stars.','It is healing Nervux. Defend the snake and break the beam.'],
  7:['The screen flashes red.','I’m Xuvren and I’m evil.','Catch 100 red bullets. Survive.']
};
export function phaseName(n){return `Phase ${n} · ${['Introduction','UFOs','M5 Miniboss','Netrex Miniboss','New Mechanics','Defend Snake',"Xuvren's Revenge"][n-1]}`;}