Place the optional PNG files here for custom boss art:
Nervux1.png, Nervux2.png, badge.png, M5.png, Netrex.png, Xuvren.png

The game intentionally runs without them and uses Canvas-drawn placeholders,
so it remains playable on GitHub Pages immediately.